package com.enderdevelopment.plugin;

import org.bukkit.Bukkit;
import org.bukkit.plugin.java.JavaPlugin;

public class Main extends JavaPlugin {

    @Override
    public void onEnable() {
        // Plugin startup logic
        getLogger().info("AbilityPlugin has been enabled!");
        
        // Register commands
        this.getCommand("announce").setExecutor(new AnnounceCommand());
        this.getCommand("rollability").setExecutor(new RollAbilityCommand());
        this.getCommand("ability").setExecutor(new AbilityCommand());
        
        // Register event listeners
        Bukkit.getPluginManager().registerEvents(new AbilityListener(), this);
    }

    @Override
    public void onDisable() {
        // Plugin shutdown logic
        getLogger().info("AbilityPlugin has been disabled!");
    }
}