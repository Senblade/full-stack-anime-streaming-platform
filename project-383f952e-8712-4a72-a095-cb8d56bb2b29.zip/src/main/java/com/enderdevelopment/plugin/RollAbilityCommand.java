package com.enderdevelopment.plugin;

import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;
import org.bukkit.scheduler.BukkitRunnable;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class RollAbilityCommand implements CommandExecutor {

    private final List<String> abilities = new ArrayList<>();

    public RollAbilityCommand() {
        // Initialize abilities
        abilities.add("Fireball");
        abilities.add("Healing");
        abilities.add("Speed Boost");
        abilities.add("Invisibility");
        abilities.add("Strength");
        abilities.add("Jump Boost");
        abilities.add("Regeneration");
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (!(sender instanceof Player)) {
            sender.sendMessage(ChatColor.RED + "This command can only be used by players.");
            return false;
        }

        Player player = (Player) sender;
        List<String> shuffledAbilities = new ArrayList<>(abilities);
        Collections.shuffle(shuffledAbilities);

        new BukkitRunnable() {
            int count = 0;

            @Override
            public void run() {
                if (count >= 20) {
                    String selectedAbility = shuffledAbilities.get(0);
                    player.sendMessage(ChatColor.GREEN + "You have been assigned the ability: " + selectedAbility);
                    cancel();
                    return;
                }

                String ability = shuffledAbilities.get(count % shuffledAbilities.size());
                player.sendMessage(ChatColor.YELLOW + "Rolling... " + ability);
                count++;
            }
        }.runTaskTimer(Bukkit.getPluginManager().getPlugin("AbilityPlugin"), 0L, 5L);

        return true;
    }
}