package com.enderdevelopment.plugin;

import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

public class AnnounceCommand implements CommandExecutor {

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (args.length == 0) {
            sender.sendMessage(ChatColor.RED + "Usage: /announce <title>");
            return false;
        }

        String title = String.join(" ", args);
        String coloredTitle = ChatColor.translateAlternateColorCodes('&', title);

        for (Player player : Bukkit.getOnlinePlayers()) {
            player.sendTitle(coloredTitle, "", 10, 70, 20);
        }

        return true;
    }
}