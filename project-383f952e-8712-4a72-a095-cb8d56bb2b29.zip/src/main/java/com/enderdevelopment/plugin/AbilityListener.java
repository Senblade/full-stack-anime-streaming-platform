package com.enderdevelopment.plugin;

import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.Location;
import org.bukkit.boss.BarColor;
import org.bukkit.boss.BarStyle;
import org.bukkit.boss.BossBar;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.inventory.CraftItemEvent;
import org.bukkit.inventory.ItemStack;
import org.bukkit.scheduler.BukkitRunnable;

public class AbilityListener implements Listener {

    @EventHandler
    public void onCraftItem(CraftItemEvent event) {
        ItemStack result = event.getRecipe().getResult();
        if (result.getItemMeta() != null && result.getItemMeta().getDisplayName() != null) {
            String displayName = result.getItemMeta().getDisplayName();
            if (displayName.contains("Ability")) {
                Player player = (Player) event.getWhoClicked();
                Location location = player.getLocation();

                // Broadcast message
                Bukkit.broadcastMessage(ChatColor.RED + "" + ChatColor.BOLD + player.getName() + " has crafted an ability at " + location.getBlockX() + ", " + location.getBlockY() + ", " + location.getBlockZ() + "!");

                // Create boss bar
                BossBar bossBar = Bukkit.createBossBar("Coordinates: " + location.getBlockX() + ", " + location.getBlockY() + ", " + location.getBlockZ(), BarColor.RED, BarStyle.SOLID);
                bossBar.addPlayer(player);

                // Schedule to remove boss bar after 15 minutes
                new BukkitRunnable() {
                    @Override
                    public void run() {
                        bossBar.removePlayer(player);
                    }
                }.runTaskLater(Bukkit.getPluginManager().getPlugin("AbilityPlugin"), 20 * 60 * 15);
            }
        }
    }
}