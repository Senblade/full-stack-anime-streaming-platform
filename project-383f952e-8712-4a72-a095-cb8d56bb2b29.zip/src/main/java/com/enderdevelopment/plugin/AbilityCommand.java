package com.enderdevelopment.plugin;

import org.bukkit.ChatColor;
import org.bukkit.Material;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.ShapedRecipe;
import org.bukkit.inventory.meta.ItemMeta;

import java.util.Arrays;

public class AbilityCommand implements CommandExecutor {

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (!(sender instanceof Player)) {
            sender.sendMessage(ChatColor.RED + "This command can only be used by players.");
            return false;
        }

        if (args.length == 0 || !args[0].equalsIgnoreCase("recipes")) {
            sender.sendMessage(ChatColor.RED + "Usage: /ability recipes");
            return false;
        }

        Player player = (Player) sender;
        player.sendMessage(ChatColor.GREEN + "Here are the ability recipes:");

        // Example recipe for Fireball ability
        ItemStack fireballAbility = new ItemStack(Material.BLAZE_POWDER);
        ItemMeta fireballMeta = fireballAbility.getItemMeta();
        fireballMeta.setDisplayName(ChatColor.RED + "Fireball Ability");
        fireballMeta.setLore(Arrays.asList(ChatColor.GRAY + "Right-click to cast a fireball."));
        fireballAbility.setItemMeta(fireballMeta);

        ShapedRecipe fireballRecipe = new ShapedRecipe(fireballAbility);
        fireballRecipe.shape("BEB", "EDE", "BEB");
        fireballRecipe.setIngredient('B', Material.BLAZE_ROD);
        fireballRecipe.setIngredient('E', Material.ENDER_PEARL);
        fireballRecipe.setIngredient('D', Material.DIAMOND);

        player.sendMessage(ChatColor.YELLOW + "Fireball Ability Recipe:");
        player.sendMessage(ChatColor.YELLOW + "B E B");
        player.sendMessage(ChatColor.YELLOW + "E D E");
        player.sendMessage(ChatColor.YELLOW + "B E B");

        // Add more recipes as needed

        return true;
    }
}